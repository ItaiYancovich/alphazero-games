"""The desktop GUI's game server, run inside the player's own browser.

The page in ``webapp/site`` is the same page ``game_gui.py`` serves; what it
talks to is this module, running in Pyodide in a Web Worker, instead of an
HTTP server.  Everything that decides anything -- the rules, the bots, the
search, the ratings table -- is the project's own Python, imported unchanged.
Three things are different, and all three are here:

* **No PyTorch.**  A small ``torch`` shim (``webapp/py/torch``) covers what the
  evaluators do around a network, and every ``load_checkpoint`` in the project
  is pointed at :class:`WebNet`, which runs the exported ONNX model through
  onnxruntime in a second worker.  The call is synchronous from Python's point
  of view -- the worker waits on shared memory for the answer -- which is what
  lets the existing agents, searches and evaluators run as they are.
* **No threads.**  Pyodide cannot start one.  The session's bot loop, the live
  analysis and the match review each become a *step* the page's worker calls
  when it is idle: :meth:`WebSession.bot_think`, :meth:`WebAnalysis.tick` and
  :meth:`WebReview.tick`.
* **No HTTP.**  :func:`dispatch` answers the same paths with the same JSON the
  desktop server's handler does, so the page's ``api()`` only has to change
  where it sends a request, not what it sends.
"""

from __future__ import annotations

import json
import os
import sys
import time
import traceback
from pathlib import Path
from types import SimpleNamespace

import numpy as np

# --------------------------------------------------------------- the network
_infer = None           # set by the worker: (model, planes) -> list of arrays
_MODELS: dict = {}      # models.json, keyed by model name
_BY_PATH: dict = {}     # checkpoint path (as the adapters spell it) -> model name


def set_infer(js_fn) -> None:
    """Install the worker's synchronous ``(model, data, dims) -> [{data, dims}]``."""
    global _infer
    from pyodide.ffi import to_js

    def run(name: str, planes: np.ndarray) -> list[np.ndarray]:
        flat = np.ascontiguousarray(planes, dtype=np.float32).reshape(-1)
        result = js_fn(name, to_js(flat), to_js([int(d) for d in planes.shape]))
        outs = []
        for item in result:
            data = np.frombuffer(item.data.to_py(), dtype=np.float32).copy()
            outs.append(data.reshape([int(d) for d in item.dims.to_py()]))
        return outs

    _infer = run


class WebNet:
    """A trained network, as far as any caller in the project can tell.

    ``cfg`` answers the same fields the checkpoint's config did, calling it
    returns the same outputs ``forward`` did (as shim tensors), and backgammon's
    ``equities`` is its own output of the exported graph.
    """

    def __init__(self, name: str):
        self.name = name
        meta = _MODELS[name]
        cfg = dict(meta.get("cfg") or {})
        self.cfg = SimpleNamespace(**cfg, to_dict=lambda: dict(cfg))
        self.outputs = list(meta["outputs"])
        self.training = False

    def _run(self, x):
        import torch

        planes = np.ascontiguousarray(np.asarray(x.a if hasattr(x, "a") else x),
                                      dtype=np.float32)
        outs = _infer(self.name, planes)
        return {n: torch.Tensor(o) for n, o in zip(self.outputs, outs)}

    def __call__(self, x):
        out = self._run(x)
        heads = [out[n] for n in self.outputs if n != "equities"]
        return heads[0] if len(heads) == 1 else tuple(heads)

    forward = __call__

    def equities(self, x):
        return self._run(x)["equities"]

    # The module protocol, for callers that move or freeze a network.
    def eval(self):
        return self

    def train(self, *_a):
        return self

    def to(self, *_a, **_k):
        return self

    def parameters(self):
        return iter(())


def _web_load(path, *_a, **_k):
    """Every ``load_checkpoint`` in the project, pointed at the ONNX models."""
    key = os.path.normpath(str(path))
    name = _BY_PATH.get(key)
    if name is None:
        raise FileNotFoundError(f"{Path(path).name} is not part of the web build")
    return WebNet(name), {}


def _patch_loaders() -> None:
    for modname, mod in list(sys.modules.items()):
        if not modname.startswith("alphazero_") or mod is None:
            continue
        for attr in ("load_checkpoint", "load_any"):
            if hasattr(mod, attr):
                setattr(mod, attr, _web_load)


# ---------------------------------------------------------------- start-up
g = None                 # game_gui, once imported
SESSION = None


def boot(root: str, models_json: str, placements_json: str) -> str:
    """Import the engine and wire it to the browser.  Returns the game list.

    ``placements`` maps each model to the checkpoint path it stands in for,
    relative to the project root; an empty file is created there so that the
    adapters' own checkpoint discovery finds exactly the shipped networks.
    """
    global g, SESSION
    _MODELS.update(json.loads(models_json))
    for name, rel in json.loads(placements_json).items():
        full = Path(root) / rel
        full.parent.mkdir(parents=True, exist_ok=True)
        if not full.exists():
            full.write_bytes(b"")
        _BY_PATH[os.path.normpath(str(full))] = name

    # Import every network module first, then point their loaders at ONNX, so
    # that a registry imported later binds the web loader, not the real one.
    import alphazero_core.net  # noqa: F401
    import alphazero_hex.net_v3  # noqa: F401
    import alphazero_bg.net  # noqa: F401
    import alphazero_splendor3.net  # noqa: F401
    for pkg in ("alphazero_c4", "alphazero_uttt", "alphazero_rps2", "alphazero_hex"):
        try:
            __import__(f"{pkg}.net")
        except Exception:
            traceback.print_exc()
    _patch_loaders()

    import game_gui
    g = game_gui
    g.DEVICE = "cpu"
    _patch_loaders()
    _adapt_games()
    SESSION = WebSession(g.DEFAULT_GAME)
    g.SESSION = SESSION
    return json.dumps(sorted(g.GAMES))


def _adapt_games() -> None:
    """The few places a game's menu must not offer what the browser lacks."""
    sp = g.GAMES["splendor"]
    cls = type(sp)
    base_catalog = cls.catalog
    # v1 and v2 of the Splendor network are not shipped; v3 beats both.
    cls.catalog = lambda self: [b for b in base_catalog(self) if b["id"] not in ("az", "az2")]
    cls.default_opponent = property(lambda self: "az3" if self.v3_checkpoint() else "planner")
    cls.v2_checkpoint = lambda self: None
    cls.checkpoints = lambda self: (["v3"] if self.v3_checkpoint() else [])
    cls.analysis_checkpoint = lambda self: ("v3" if self.v3_checkpoint() else "")
    # Its live evaluation is built on the v1/v2 networks.
    cls.analysable = False

    # Ultimate Tic-Tac-Toe's v3 opponents need a compiled Rust extension.
    ut = g.GAMES["uttt"]
    ucls = type(ut)
    u_catalog = ucls.catalog
    ucls.catalog = lambda self: [b for b in u_catalog(self) if not b["id"].startswith("v3")]


# ----------------------------------------------------------------- analysis
class WebAnalysis:
    """The desktop ``Analysis``, advanced one step at a time by the page."""

    def __new__(cls):
        base = g.Analysis

        class _Web(base):
            def configure(self, enabled: bool, max_sims: int) -> None:
                with self.lock:
                    was_off = not self.enabled
                    self.enabled = enabled
                    self.max_sims = max(1, int(max_sims))
                    if was_off and enabled:
                        self._result = {}

            def busy(self) -> bool:
                """Is there anything for :meth:`tick` to do?"""
                with self.lock:
                    enabled, wanted = self.enabled, self._wanted
                if not enabled or wanted is None:
                    return False
                board, key, ckpt, game = wanted
                if not game.analysable:
                    return self._key is not None
                if not game.uses_search:
                    return key != self._key or getattr(self, "_stream", None) is not None
                if key != self._key or self._search is None:
                    return True
                return self._search.sims_done < self.max_sims

            def tick(self) -> None:
                """One pass of the desktop worker loop, without its sleeps."""
                with self.lock:
                    enabled, ceiling, wanted = self.enabled, self.max_sims, self._wanted
                if not enabled or wanted is None:
                    return
                board, key, ckpt, game = wanted
                try:
                    if not game.analysable:
                        if self._key is not None:
                            self._key = None
                            self._search = None
                            self._store({})
                        return
                    if not game.uses_search:
                        if key != self._key:
                            self._key = key
                            self._board = board.copy()
                            self._game = game
                            self._search = None
                            self._stream = game.analysis_stream(board, ckpt)
                        stream = getattr(self, "_stream", None)
                        if stream is None:
                            return
                        try:
                            self._store(dict(next(stream), error=None))
                        except StopIteration:
                            self._stream = None
                        return
                    if key != self._key:
                        self._start(game, board, key, ceiling)
                    if self._search is None:
                        return
                    self._search.cfg.simulations = ceiling
                    if self._search.sims_done >= ceiling:
                        return
                    self._step(game, board, key, ckpt)
                except Exception as exc:  # noqa: BLE001 -- shown on the panel
                    traceback.print_exc()
                    self._publish_error(f"analysis stopped: {exc}")
                    with self.lock:
                        self.enabled = False

        return _Web()


# ------------------------------------------------------------------- review
class WebReview:
    """The desktop ``MatchReview``, one position per :meth:`tick`."""

    def __new__(cls):
        base = g.MatchReview

        class _Web(base):
            def __init__(self):
                super().__init__()
                self._job = None

            def start(self, game, moves, size_id, ckpt, sims):
                if not game.reviewable:
                    return f"match review is not available for {game.label}"
                if len(moves) < 2:
                    return "nothing to analyse yet"
                with self.lock:
                    if self._state["running"]:
                        return "already analysing this game"
                    self._token += 1
                    token = self._token
                    self._state = dict(self._blank(), running=True, total=len(moves) + 1,
                                       sims=int(sims), ckpt=ckpt, workers=1)
                self._job = (token, self._serial(token, game, list(moves), size_id,
                                                 ckpt, int(sims)), list(moves))
                return None

            def clear(self):
                super().clear()
                self._job = None

            def busy(self) -> bool:
                return self._job is not None

            def _serial(self, token, game, moves, size_id, ckpt, sims):
                """``_run_serial`` from the desktop, pausing after each position."""
                from alphazero_core.mcts import run_search

                board = game.new_board(size_id)
                engine = game.evaluator(ckpt, board)
                cfg = g.MCTSConfig(simulations=sims, c_puct=1.6, add_noise=False)
                search = None
                previous_board = None
                plies = []
                for index in range(len(moves) + 1):
                    if board.is_terminal():
                        entry = game.terminal_readout(board)
                        search = None
                    else:
                        search = g.reuse_or_new(search, previous_board, board, cfg, sims)
                        search.cfg.simulations = sims
                        run_search(search, engine, sims, self.BATCH)
                        entry = game.readout(search, board)
                        previous_board = board.copy()
                    entry["ply"] = index
                    plies.append(entry)
                    self._advance(token)
                    if index < len(moves):
                        board.play(moves[index])
                    yield None
                return plies

            def tick(self) -> None:
                if self._job is None:
                    return
                token, job, moves = self._job
                if not self._alive(token):
                    self._job = None
                    return
                try:
                    next(job)
                except StopIteration as done:
                    self._job = None
                    plies = done.value
                    for index, entry in enumerate(plies):
                        entry["played"] = int(moves[index]) if index < len(moves) else None
                    with self.lock:
                        if token != self._token:
                            return
                        self._state["plies"] = plies
                    self._finish(token)
                except Exception as exc:  # noqa: BLE001 -- shown in the banner
                    traceback.print_exc()
                    self._job = None
                    self._fail(token, f"analysis failed: {exc}")

        return _Web()


# ------------------------------------------------------------------ session
def WebSession(game: str):  # noqa: N802 -- a class, built once game_gui exists
    base = g.Session

    class _Web(base):
        """The desktop session, with the bot loop turned inside out.

        ``_wake_bot`` only raises the flag; the page's worker then calls
        :meth:`bot_think` (search, which may take seconds) and, after waiting
        out the pace, :meth:`bot_commit` (play it).  Everything between those
        calls -- a new game, a take-back, a changed opponent -- bumps
        ``generation`` exactly as it does on the desktop, and a stale move is
        dropped exactly as it is there.
        """

        def __init__(self, game_key):
            super().__init__(game_key)
            self.analysis = WebAnalysis()
            self.review = WebReview()
            self._bot_gen = None
            self._planned = None
            # Online play: seats played from another browser.  They count as
            # humans here; the page decides whose clicks may move them.
            self.remote_seats: set[int] = set()

        def _wake_bot(self) -> None:
            with self.lock:
                if self.thinking or self.board.is_terminal():
                    return
                if self.agents[self.board.to_move] is None:
                    return
                self.thinking = True
                self._bot_gen = self.generation
                self._planned = None
                self._touch()

        def bot_pending(self) -> bool:
            with self.lock:
                return (self.thinking and self._bot_gen == self.generation
                        and not self.board.is_terminal()
                        and self.agents.get(self.board.to_move) is not None)

        def bot_think(self) -> float:
            """Choose the bot's move.  Returns how long to hold it before playing."""
            with self.lock:
                gen = self.generation
                if not self.bot_pending():
                    self._settle(gen)
                    return -1.0
                agent = self.agents[self.board.to_move]
                position = self.board.copy()
                last = self.moves[-1].get("cell") if self.moves else None
                game = self.game
            started = time.time()
            try:
                cell = game.select(agent, position, last)
            except Exception:
                traceback.print_exc()
                with self.lock:
                    if gen == self.generation:
                        self.error = "the bot crashed while thinking"
                        self.thinking = False
                        self._touch()
                return -1.0
            self._planned = (gen, cell, agent)
            return max(0.0, game.bot_pause * self.pace - (time.time() - started))

        def bot_commit(self) -> None:
            planned, self._planned = self._planned, None
            if planned is None:
                return
            gen, cell, agent = planned
            with self.lock:
                if gen != self.generation:
                    return
                self._record(cell, agent.name)
                self.info = self._agent_info(agent)
                # Still a bot on turn: stay "thinking" for the next one.
                if self.board.is_terminal() or self.agents.get(self.board.to_move) is None:
                    self.thinking = False
                self._bot_gen = self.generation
                self._touch()

        def _settle(self, gen) -> None:
            if gen == self.generation and self.thinking:
                self.thinking = False
                self._touch()

        def set_remote(self, seats) -> None:
            with self.lock:
                self.remote_seats = {int(s) for s in seats}
                self._touch()

        def snapshot(self) -> dict:
            out = super().snapshot()
            out["remote_seats"] = sorted(self.remote_seats)
            return out

    return _Web(game)


# ---------------------------------------------------------------- dispatch
def _bots_payload() -> dict:
    current = SESSION.game
    return dict(
        games=[g.game_blob(g.GAMES[k])
               for k in ("hex", "c4", "uttt", "uxx", "rps2", "bg", "splendor")],
        game=current.key,
        bots=current.catalog(), checkpoints=current.checkpoints(),
        sizes=current.sizes,
        sim_stops=g.SIM_STOPS, eval_stops=g.EVAL_STOPS[:6],
        review_stops=[s for s in g.REVIEW_STOPS if s <= 800] or g.REVIEW_STOPS,
        default_review_sims=min(g.DEFAULT_REVIEW_SIMS, 400),
        analysis_ckpt=current.analysis_checkpoint(),
        default_sims=g.DEFAULT_SIMS, default_eval_sims=g.DEFAULT_EVAL_SIMS,
        users=sorted(current.R.load_users()),
        provisional_games=current.R.PROVISIONAL_GAMES,
        web=True)


def dispatch(path: str, body_json: str | None) -> str:
    """One request, answered as the desktop handler answers it."""
    try:
        status, payload = _dispatch(path, json.loads(body_json) if body_json else None)
    except Exception as exc:  # noqa: BLE001 -- the page shows it in the banner
        traceback.print_exc()
        status, payload = 500, dict(error=f"the game engine failed -- "
                                           f"{type(exc).__name__}: {exc}")
    return json.dumps(dict(status=status, body=payload))


def _with(payload: dict, problem: str | None) -> dict:
    return dict(payload, problem=problem) if problem else payload


def _dispatch(path: str, body: dict | None):
    S = SESSION
    if body is None:
        if path == "/api/bots":
            return 200, _bots_payload()
        if path == "/api/state":
            return 200, S.snapshot()
        if path.startswith("/api/training"):
            return 200, {}
        return 404, dict(error="no such endpoint")

    if path == "/api/new":
        problem = S.new_game(
            game=body.get("game") or None,
            black=str(body.get("black", "human")),
            white=str(body.get("white", "rule")),
            size=str(body.get("size") or ""),
            ckpt=str(body.get("ckpt") or ""),
            seed=int(body.get("seed", 0)),
            black_sims=int(body.get("black_sims", g.DEFAULT_SIMS)),
            white_sims=int(body.get("white_sims", g.DEFAULT_SIMS)),
            black_vary=bool(body.get("black_vary", False)),
            white_vary=bool(body.get("white_vary", False)),
            black_ckpt=body.get("black_ckpt") or None,
            white_ckpt=body.get("white_ckpt") or None,
            players=body.get("players") or None,
            rated=bool(body.get("rated", False)))
        return 200, _with(S.snapshot(), problem)
    if path == "/api/opponent":
        if body.get("seat") is not None:
            index = max(0, min(int(body["seat"]), len(S.seats) - 1))
            seat = S.seats[index]
        else:
            seat = S.seats[0 if str(body.get("colour")) == "black" else 1]
        problem = S.set_opponent(seat, str(body.get("choice", "human")),
                                 int(body.get("sims", g.DEFAULT_SIMS)),
                                 bool(body.get("vary", False)), body.get("ckpt") or None)
        return 200, _with(S.snapshot(), problem)
    if path == "/api/review":
        with S.lock:
            game, moves, size = S.game, [m["cell"] for m in S.moves], S.size
        problem = S.review.start(game, moves, size, game.analysis_checkpoint(),
                                 int(body.get("sims", g.DEFAULT_REVIEW_SIMS)))
        return 200, _with(S.snapshot(), problem)
    if path == "/api/pace":
        S.set_pace(float(body.get("pace", 1.0)))
        return 200, S.snapshot()
    if path == "/api/analysis":
        S.analysis.configure(bool(body.get("enabled", False)),
                             int(body.get("max_sims", g.DEFAULT_EVAL_SIMS)))
        S.analysis.set_position(S.game, S.board, S.game.analysis_checkpoint())
        return 200, S.snapshot()
    if path == "/api/user":
        R = S.game.R
        problem = None
        if body.get("action") == "create":
            _, problem = R.create_user(str(body.get("name", "")))
        if problem is None:
            S.select_user(str(body.get("name", "")).strip() or None)
        return 200, _with(dict(S.snapshot(), users=sorted(R.load_users())), problem)
    if path == "/api/move":
        problem = S.play_human(S.game.parse_move(body, S.board))
        return (200 if problem is None else 409), _with(S.snapshot(), problem)
    if path == "/api/undo":
        problem = S.undo()
        return (200 if problem is None else 409), _with(S.snapshot(), problem)
    if path == "/api/remote":
        S.set_remote(body.get("seats") or [])
        return 200, S.snapshot()
    return 404, dict(error="no such endpoint")


# ---------------------------------------------------------- background work
def work() -> str:
    """What the worker should do next when it is otherwise idle.

    ``"bot"`` -- a bot is on turn; ``"review"`` / ``"analysis"`` -- a panel has
    work; ``""`` -- nothing.  The bot comes first: it is the game.
    """
    S = SESSION
    if S is None:
        return ""
    if S.bot_pending():
        return "bot"
    if S.review.busy():
        return "review"
    if S.analysis.busy():
        return "analysis"
    return ""


def step(kind: str) -> float:
    """Do one unit of ``kind``.  For a bot, returns the pause before playing."""
    S = SESSION
    if kind == "bot":
        return S.bot_think()
    if kind == "commit":
        S.bot_commit()
        return 0.0
    if kind == "review":
        S.review.tick()
    elif kind == "analysis":
        S.analysis.tick()
    return 0.0
